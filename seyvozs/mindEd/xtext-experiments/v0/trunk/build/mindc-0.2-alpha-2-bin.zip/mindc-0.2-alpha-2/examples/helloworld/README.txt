################################################################################
#   Mind Helloworld example: OVERVIEW
################################################################################

This example shows a very basic Fractal application with a main composite 
component containing a client and a server.


################################################################################
#   LAUNCHING THE BASE EXAMPLE WITH MAKE
################################################################################
From the command line, simply type:
 $ make helloworld
  
  
Afterwards, execute the binary "hw" file with:
 $ build/hw

 
You should see the client calling 2 times the print method on the server.
